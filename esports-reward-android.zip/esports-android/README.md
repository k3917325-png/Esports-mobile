# Esports Reward — Android (WebView wrapper)

Yeh ek native Android project hai jo tumhare `esports-reward-app.html` ko
ek thin WebView ke andar load karta hai (koi logic duplicate nahi — poori
app wahi HTML/JS hai, sirf Android APK/AAB shell diya gaya hai).

- Package name: `com.mobile.esports`
- App name: Esports Reward

## Signed .aab automatically banwana (GitHub Actions)

Is repo me `.github/workflows/build-aab.yml` already hai jo GitHub ke apne
servers par (free, Android SDK pre-installed) signed release `.aab` bana
deta hai — tumhare apne computer par kuch install karne ki zaroorat nahi.

### One-time setup (repo banane ke baad):

1. Repo ke **Settings → Secrets and variables → Actions → New repository secret**
   me yeh 4 secrets add karo:

   | Secret name | Value |
   |---|---|
   | `RELEASE_KEYSTORE_BASE64` | `release-key.jks.base64` file ka poora content (ek line) |
   | `RELEASE_KEYSTORE_PASSWORD` | keystore password (passwords.txt me diya hai) |
   | `RELEASE_KEY_ALIAS` | `esportsreward` |
   | `RELEASE_KEY_PASSWORD` | keystore password jaisa hi (PKCS12 keystore me dono same hote hain) |

2. Code push karo (`git push`) ya **Actions** tab me jaake workflow ko
   manually "Run workflow" se trigger karo.

3. Ab ek hi run mein **signed APK** (direct install/testing ke liye) aur **signed AAB** (Play Store ke liye) dono bante hain. Build complete hone ke baad, **Actions → latest run → Artifacts** section
   me `app-release-aab` milega — download karke unzip karo, andar
   `app-release.aab` hogi. Yahi file Play Console ke Closed Testing upload
   box me daalni hai.

### ⚠️ Keystore safety

`release-key.jks` tumhari **upload key** hai. Ise aur `passwords.txt` ko
surakshit rakho (password manager / private cloud storage) — agar kabhi
is app ka future update upload karna ho to yehi key dobara chahiye hoga.
Yeh file is repo me commit NAHI ki gayi hai (`.gitignore` me hai) — sirf
base64 secret ke roop me GitHub Actions ko di jaati hai.

## HTML app update karne ke baad

Jab bhi `esports-reward-app.html` (artifact) update ho, uski latest copy
`app/src/main/assets/index.html` par copy karke push kar do — agli build
me naya version apne aap include ho jayega.

## Local build (optional, agar kabhi Android Studio/SDK ho)

```
./gradlew :app:bundleRelease
```
(signing ke liye upar wale 4 env vars set hone chahiye, warna unsigned
build banegi jo Play Console accept nahi karega.)

## APK (direct install / testing)

Same run ke **Artifacts** mein `app-release-apk` milega → unzip karke `app-release.apk` phone mein install karo
("Install unknown apps" allow karna padega). Yeh APK aur AAB **same keystore** se sign hote hain, isliye
baad mein Play Store par update upload karna possible rehta hai — keystore kabhi mat khona.

## Production build ke liye GitHub *Variables* (Settings → Secrets and variables → Actions → **Variables** tab)

Yeh public identifiers hain (secret nahi), isliye Variables mein jate hain:

| Variable | Value |
|---|---|
| `CLOUD_API_URL` | Deployed backend ka https URL (jaise `https://your-api.example.com`) — build ke time app mein `CLOUD_API_DEFAULT` ban kar bake ho jata hai |
| `ADMOB_APP_ID` | AdMob App ID: `ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY` |
| `ADMOB_REWARDED_ID` | Rewarded Ad Unit ID: `ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY` |

Teeno set na hon (ya Google ke test ids hon) to workflow **fail** ho jata hai, taaki galti se test config Play Store par na chala jaye.
Sirf testing ke liye: Actions → Run workflow → `allow_test_config` ON (us build ko Play par upload mat karna).

AdMob console mein: (1) app add karo, (2) Rewarded ad unit banao, (3) Privacy & messaging → EU/UK consent message publish karo (UMP form tabhi dikhega).
